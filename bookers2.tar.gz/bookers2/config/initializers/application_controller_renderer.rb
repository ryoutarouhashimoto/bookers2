# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '55d4ae0a929af2a90e9ae21940f4ade85502b48a047a95b2673f908741ffc70cd742efb9ea32c2be4344481fb36a29c44745325017692e414cc5bc242adf34ec'
